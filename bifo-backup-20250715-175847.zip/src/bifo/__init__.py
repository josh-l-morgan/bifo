# -*- coding: utf-8 -*-
"""
Created on Sun Jul 13 05:55:19 2025

@author: jlmorgan
"""

