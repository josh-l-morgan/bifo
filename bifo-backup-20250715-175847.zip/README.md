<<<<<<< HEAD
\# bifo



\*\*bifo\*\* is a collection of biological image processing modules tangentially related to bifoveate retinas.



\*trainTools\* Includes miscellaneous tools for training Unets to analyze 3D volumes

\*fetchChunkFromMips\* creates the class fetchDiced that reads a diced volume directory if images (diced/section\_number/mip\_level) and delivers 3D image chunks







\## Installation



```bash

pip install .

```



\## Usage



```python

import bifo.trainTools as tt
from bifo.fetchChunckFromMips import fetchDiced

```



\## License



This project is licensed under the MIT License — see the \[LICENSE](LICENSE) file for details.



\## Citation



If you use this package in your research, please cite it as described in `CITATION.cff`.



=======
# bifo
Package of biological image processing modules named after bifoveate retinas
>>>>>>> 228390711efd709420f98e4afca4d897966377e3
